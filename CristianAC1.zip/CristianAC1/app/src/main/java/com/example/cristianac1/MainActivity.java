package com.example.cristianac1;

import android.os.Bundle;
import android.util.Log;

import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText editTextTitle;
    private EditText editTextAuthor;
    private CheckBox checkBoxCompleted;
    private Button buttonAddBook;
    private LinearLayout linearLayoutBooks;

    private ArrayList<String> bookList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextTitle = findViewById(R.id.editTextTitle);
        editTextAuthor = findViewById(R.id.editTextAuthor);
        checkBoxCompleted = findViewById(R.id.checkBoxCompleted);
        buttonAddBook = findViewById(R.id.buttonAddBook);
        linearLayoutBooks = findViewById(R.id.linearLayoutBooks);
        buttonAddBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addBookToList();
            }
        });
    }

    private void addBookToList() {
        String title = editTextTitle.getText().toString().trim();
        String author = editTextAuthor.getText().toString().trim();

        boolean isCompleted = checkBoxCompleted.isChecked();

        if (title.isEmpty() || author.isEmpty()) {
            Toast.makeText(this, "Preencha o Título e o Autor.", Toast.LENGTH_SHORT).show();
            return;
        }

        String readStatus = isCompleted ? "Lido" : "Não Lido";
        String bookDetails = "Título: " + title + "\n" +
                "Autor: " + author + "\n" +
                "Status: " + readStatus;

        bookList.add(bookDetails);
        editTextTitle.setText("");
        editTextAuthor.setText("");
        checkBoxCompleted.setChecked(false);
        Toast.makeText(this, "Livro adicionado!", Toast.LENGTH_SHORT).show();
        updateBookListView();
    }

    private void updateBookListView() {
        linearLayoutBooks.removeAllViews();
        for (String bookInfo : bookList) {
            TextView bookTextView = new TextView(this);
            bookTextView.setText(bookInfo);
            bookTextView.setTextSize(16);
            bookTextView.setPadding(0, 8, 0, 24);
            linearLayoutBooks.addView(bookTextView);
        }
    }
}